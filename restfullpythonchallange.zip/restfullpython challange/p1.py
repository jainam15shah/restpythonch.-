#!/usr/bin/env python3

import argparse
import json
import csv
import requests

class RestfulClient:
    def __init__(self, base_url="https://jsonplaceholder.typicode.com"):
        self.base_url = base_url

    def get_data(self, endpoint):
        response = requests.get(f"{self.base_url}{endpoint}")
        return response

    def post_data(self, endpoint, data):
        response = requests.post(f"{self.base_url}{endpoint}", json=data)
        return response

    def handle_response(self, response, outfile=None):
        print(f"HTTP Status Code: {response.status_code}")
        if not response.ok:
            print(f"Error: {response.text}")
            exit(1)

        if outfile:
            self.save_to_file(response.json(), outfile)
        else:
            print(json.dumps(response.json(), indent=2))

    def save_to_file(self, data, outfile):
        if outfile.endswith(".json"):
            with open(outfile, "w") as json_file:
                json.dump(data, json_file, indent=2)
        elif outfile.endswith(".csv"):
            with open(outfile, "w", newline="") as csv_file:
                csv_writer = csv.DictWriter(csv_file, fieldnames=data[0].keys())
                csv_writer.writeheader()
                csv_writer.writerows(data)
        else:
            print("Unsupported file format. Supported formats: .json, .csv")
            exit(1)

def main():
    parser = argparse.ArgumentParser(description="Simple command-line REST client for JSONPlaceholder")
    parser.add_argument("METHOD", choices=["get", "post"], help="HTTP method (get or post)")
    parser.add_argument("ENDPOINT", help="URI fragment, e.g., /posts/1")
    parser.add_argument("-o", "--output", metavar="OUTFILE", help="Output file (json or csv)")

    args = parser.parse_args()

    rest_client = RestfulClient()

    if args.METHOD == "get":
        response = rest_client.get_data(args.ENDPOINT)
    elif args.METHOD == "post":
        data = {"key": "value"}  # Replace with actual data to be posted
        response = rest_client.post_data(args.ENDPOINT, data)

    rest_client.handle_response(response, args.output)

if __name__ == "__main__":
    main()
